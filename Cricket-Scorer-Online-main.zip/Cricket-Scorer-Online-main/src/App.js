import './App.css';
import Start from './components/startGame';

function App() {
  return (
    <div className="bg-[#222831] min-h-screen">
      <Start/>
    </div>
  );
}

export default App;
